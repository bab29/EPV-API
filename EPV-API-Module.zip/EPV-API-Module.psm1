﻿#Region '.\Public\Start.ps1' -1

function Get-Hello {
    [CmdletBinding()]
    param (
        
    )
    
    begin {
        
    }
    
    process {
        "Hello"
    }
    
    end {
        
    }
}
#EndRegion '.\Public\Start.ps1' 19
